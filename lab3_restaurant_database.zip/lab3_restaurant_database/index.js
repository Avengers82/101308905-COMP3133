// app.js
const express = require('express');
const mongoose = require('mongoose');
const Restaurant = require('./restaurant');

const app = express();
const PORT = 3000;

mongoose.connect('mongodb+srv://pavansunny93:fallstack2@cluster0.0mjuas6.mongodb.net/lab3_restaurant_database?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

//REST API to return all restaurant details

app.get('/restaurants', async (req, res) => {
  try {
    const restaurants = await Restaurant.find();
    res.json(restaurants);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

//REST API to return restaurant details by cuisine

app.get('/restaurants/cuisine/:cuisine', async (req, res) => {
    const { cuisine } = req.params;
    try {
      const restaurants = await Restaurant.find({ cuisines: cuisine });
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

//REST API for sorting by restaurant_id

app.get('/restaurants', async (req, res) => {
    const { sortBy } = req.query;
    try {
      const restaurants = await Restaurant.find().sort({ restaurant_id: sortBy === 'ASC' ? 1 : -1 });
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

//REST API for Delicatessen and city not equal to Brooklyn

app.get('/restaurants/:cuisine', async (req, res) => {
    const { cuisine } = req.params;
    try {
      const restaurants = await Restaurant.find({ cuisines: cuisine, city: { $ne: 'Brooklyn' } })
        .select({ id: 0, cuisines: 1, name: 1, city: 1, restaurant_id: 1 })
        .sort({ name: 1 });
  
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
  id: Number,
  cuisines: String,
  name: String,
  city: String,
  restaurant_id: Number,
});

const Restaurant = mongoose.model('Restaurant', restaurantSchema);

module.exports = Restaurant;
